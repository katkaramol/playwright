import { test, expect } from '@playwright/test';

test.describe('Fund Module', () => {

  test('Verify fund transfer flow', async ({ page }) => {
    await page.goto('/fund-transfer');
    await page.fill('input[name="amount"]', '1000');
    await page.click('button[type="submit"]');

    await expect(page.locator('.toast-success')).toContainText('Transfer successful');
  });

});
