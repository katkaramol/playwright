import { test, expect } from '@playwright/test';

test.describe('Dashboard Module', () => {

  test('Check user widgets visible', async ({ page }) => {
    await page.goto('/dashboard');
    await expect(page.locator('.widget')).toHaveCount(3);
  });

});
