import { test, expect } from '@playwright/test';

test.describe('Login Module', () => {

  test('Valid login should navigate to dashboard', async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[name="email"]', 'valid_user@corp.com');
    await page.fill('input[name="password"]', 'ValidPass123');
    await page.click('button[type="submit"]');

    await expect(page).toHaveURL(/dashboard/);
    await expect(page.locator('h1.greeting')).toContainText('Welcome');
  });

  test('Invalid login should show error', async ({ page }) => {
    await page.goto('/login');
    await page.fill('input[name="email"]', 'wrong@corp.com');
    await page.fill('input[name="password"]', 'BadPass');
    await page.click('button[type="submit"]');

    await expect(page.locator('.toast-error')).toContainText('Invalid');
  });

});
