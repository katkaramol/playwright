import { test, expect } from '@playwright/test';

test('Login and verify dashboard', async ({ page }) => {
  // Go to login page
  await page.goto('http://localhost:5173/');

  // Login
  await page.fill('input[name="username"]', 'subha');
  await page.fill('input[name="password"]', '123456');
  await page.click('button[type="submit"]');

  // Verify popup
  await expect(page.locator('text=Login Successful')).toBeVisible();
  await expect(page.locator('text=Welcome subha')).toBeVisible();

  // Click OK
  await page.click('button:has-text("OK")');

  // Verify URL after OK
  await expect(page).toHaveURL(/.*dashboard/);

  // Verify Dashboard elements
  //await expect(page.locator('h1, h2, h3, h4, h5, h6')).toContainText('Welcome');
  await expect(page.locator('text=Total Investment')).toBeVisible();
  await expect(page.locator('text=Returns')).toBeVisible();
  await expect(page.locator('text=Active Funds')).toBeVisible();
  await expect(page.locator('text=Risk Profile')).toBeVisible();

  // Verify "VIEW ALL TRANSACTIONS" button
  await expect(page.locator('button:has-text("VIEW ALL TRANSACTIONS")')).toBeVisible();
});   // 👈 yaha close kiya test ko

test('Invalid login should show error popup', async ({ page }) => {
  // Go to login page
  await page.goto('http://localhost:5173/');

  // Fill wrong credentials
  await page.fill('input[name="username"]', 'wrong@corp.com');
  await page.fill('input[name="password"]', 'WrongPass123');
  await page.click('button[type="submit"]');

  // Verify error popup
  await expect(page.locator('text=Invalid Credentials')).toBeVisible();
  await expect(page.locator('text=Please check your username and password')).toBeVisible();

  // Click OK on error popup
  await page.click('button:has-text("OK")');

  // Stay on login page (URL check)
  //await expect(page).toHaveURL(/.*login/);
});
